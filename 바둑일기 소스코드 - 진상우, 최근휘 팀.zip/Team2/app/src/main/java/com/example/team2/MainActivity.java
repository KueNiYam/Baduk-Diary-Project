package com.example.team2;

import android.Manifest;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Environment;
import android.support.annotation.NonNull;
import android.support.design.widget.BottomNavigationView;
import android.support.v4.app.ActivityCompat;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentManager;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;
import android.support.v7.widget.Toolbar;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
    private Toolbar toolbar;

    private FragmentManager fragmentManager = getSupportFragmentManager();

    private HomeFragment homeFragment = new HomeFragment();
    private ListFragment listFragment = new ListFragment();
    private EditorFragment editorFragment = new EditorFragment();
    private MoreFragment moreFragment = new MoreFragment();

    private BottomNavigationView.OnNavigationItemSelectedListener mOnNavigationItemSelectedListener
            = new BottomNavigationView.OnNavigationItemSelectedListener() {
        FragmentTransaction transaction;

        @Override
        public boolean onNavigationItemSelected(@NonNull MenuItem item) {
            transaction = fragmentManager.beginTransaction();
            switch (item.getItemId()) {
                case R.id.navigation_home:
                    transaction.replace(R.id.frame_layout, homeFragment).commitAllowingStateLoss();
                    getSupportActionBar().setIcon(R.drawable.baseline_home_black_24dp);
                    getSupportActionBar().setTitle(R.string.title_home);
                    return true;
                case R.id.navigation_list:
                    transaction.replace(R.id.frame_layout, listFragment).commitAllowingStateLoss();
                    getSupportActionBar().setTitle(R.string.title_list);
                    getSupportActionBar().setIcon(R.drawable.baseline_list_black_24dp);
                    return true;
                case R.id.navigation_editor:
                    transaction.replace(R.id.frame_layout, editorFragment).commitAllowingStateLoss();
                    getSupportActionBar().setTitle(R.string.title_editor);
                    getSupportActionBar().setIcon(R.drawable.baseline_create_black_24dp);
                    return true;
                case R.id.navigation_more:
                    transaction.replace(R.id.frame_layout, moreFragment).commitAllowingStateLoss();
                    getSupportActionBar().setTitle(R.string.title_more);
                    getSupportActionBar().setIcon(R.drawable.baseline_more_horiz_black_24dp);
                    return true;
            }
            return false;
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        ActivityCompat.requestPermissions(this,
                new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE},
                1);
        // 툴바
        toolbar = (Toolbar) findViewById(R.id.toolbar); //툴바설정
        toolbar.setTitleTextColor(Color.parseColor("#000000"));
        setSupportActionBar(toolbar); // 액션바와 같게 만들어줌
        getSupportActionBar().setIcon(R.drawable.baseline_home_black_24dp);
        getSupportActionBar().setTitle(R.string.title_home);
        /*----------------------------------------------------------------------------------------*/

        BottomNavigationView navigation = (BottomNavigationView) findViewById(R.id.navigation);

        // 첫 화면 지정
        FragmentTransaction transaction = fragmentManager.beginTransaction();
        transaction.replace(R.id.frame_layout, homeFragment).commitAllowingStateLoss();

        navigation.setOnNavigationItemSelectedListener(mOnNavigationItemSelectedListener);
    }

}
