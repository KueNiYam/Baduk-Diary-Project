package com.example.team2;

import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.os.Environment;
import android.support.v4.app.Fragment;
import android.support.v4.app.FragmentTransaction;
import android.support.v7.app.AppCompatActivity;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

public class EditActivity extends AppCompatActivity {
    int count =0;
    int black_dead=0;
    int white_dead=0;
    int comment_count=0;
    TextView tv_blackdead;
    TextView tv_whitedead;
    ImageButton gobutton[][] = new ImageButton[19][19];
    int Lastrow=0, Lastcol=0;

    String BlackPlayer;
    String WhitePlayer;
    class MyClickListener implements View.OnClickListener {
        int row;
        int col;
        char c_row;
        char c_col;

        public MyClickListener(int r, int c) {
            row = r;
            col = c;
            int c_temp=c+97;
            int r_temp=r+97;
            c_col= (char)c_temp ;
            c_row= (char)r_temp ;

        }


        @Override
        public void onClick(View v) {
            if (gobutton[row][col].getBackground().getConstantState().equals(getResources().getDrawable(R.drawable.black).getConstantState())) {
                //클릭한 버튼에 흑돌이 있을 경우
                gobutton[row][col].setBackgroundColor(Color.TRANSPARENT);
                black_dead++;
                Toast.makeText(EditActivity.this, "흑돌 들어내기", Toast.LENGTH_SHORT).show();
                tv_blackdead.setText(Integer.toString(black_dead));

            } else if (gobutton[row][col].getBackground().getConstantState().equals(getResources().getDrawable(R.drawable.white).getConstantState())) {
                //클릭한 버튼에 흑돌이 있을 경우
                gobutton[row][col].setBackgroundColor(Color.TRANSPARENT);
                white_dead++;
                Toast.makeText(EditActivity.this, "백돌 들어내기", Toast.LENGTH_SHORT).show();
                tv_whitedead.setText(Integer.toString(white_dead));
            } else {
                count++;
                if (count % 2 == 1) {
                    gobutton[row][col].setBackgroundResource(R.drawable.black);
                    Lastrow = row;
                    Lastcol = col;
                    String str = "B[" + c_col + c_row + "];";
                    Toast.makeText(EditActivity.this, Integer.toString(count), Toast.LENGTH_SHORT).show();
                    try {
                        BufferedWriter bw = new BufferedWriter(new FileWriter(getFilesDir() + "test.txt", true));
                        bw.write(str);
                        bw.close();

                    } catch (Exception e) {
                        e.printStackTrace();
                    }

                } else {
                    gobutton[row][col].setBackgroundResource(R.drawable.white);
                    Lastrow = row;
                    Lastcol = col;
                    String str = "W[" + c_col + c_row + "];";

                    Toast.makeText(EditActivity.this, Integer.toString(count), Toast.LENGTH_SHORT).show();
                    try {
                        BufferedWriter bw = new BufferedWriter(new FileWriter(getFilesDir() + "test.txt", true));
                        bw.write(str);
                        bw.close();

                    } catch (Exception e) {
                        e.printStackTrace();
                    }

                }
            }
        }

    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit);

        Intent intent;
        intent = getIntent();
        BlackPlayer=intent.getStringExtra("BlackName") ;
        WhitePlayer=intent.getStringExtra("WhiteName") ;

        final String player_black="/"+BlackPlayer;
        final String player_white="vs"+WhitePlayer;



        tv_blackdead= (TextView)findViewById(R.id.TV_BlackDead);
        tv_whitedead= (TextView)findViewById(R.id.TV_WhitekDead);

        TextView tv_bp= (TextView)findViewById(R.id.TV_BP);
        TextView tv_bw= (TextView)findViewById(R.id.TV_BW);

        tv_bp.setText(BlackPlayer);
        tv_bw.setText(WhitePlayer);
        Toast.makeText(EditActivity.this, BlackPlayer+" : "+WhitePlayer, Toast.LENGTH_SHORT).show();
        final RelativeLayout gobanLayout= (RelativeLayout)findViewById(R.id.goabnLayout);
        final LinearLayout allLayout=(LinearLayout)findViewById(R.id.allLayout);
        Button loadbutton= (Button)findViewById(R.id.load_button);
        Button savebutton= (Button)findViewById(R.id.save_button);
        Button addcommentbutton= (Button)findViewById(R.id.add_comment_button);
        Button backbutton=(Button)findViewById(R.id.back_button);


        final EditText comment=(EditText)findViewById(R.id.edit_comment);
        loadbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {try{
                BufferedReader br = new BufferedReader(new FileReader(getFilesDir()+"test.txt"));
                String readStr = "";
                String str = null;
                while(((str = br.readLine()) != null)){
                    readStr += str +"\n";
                }
                br.close();

                Toast.makeText(EditActivity.this, readStr.substring(0, readStr.length()-1), Toast.LENGTH_SHORT).show();

            }catch (FileNotFoundException e){
                e.printStackTrace();
            }catch (IOException e) {
                e.printStackTrace();
            }
            }
        });

        savebutton.setOnClickListener(new View.OnClickListener() {
                                          @Override
                                          public void onClick(View v) {
                                              File saveFile = new File(Environment.getExternalStorageDirectory() + "/Baduk_Comment" + player_black + player_white); // 저장 경로
// 폴더 생성
                                              if (!saveFile.exists()) { // 폴더 없을 경우
                                                  saveFile.mkdirs(); // 폴더 생성
                                              }
                                              try {
                                                  BufferedWriter buf = new BufferedWriter(new FileWriter(saveFile + "/comment_count.txt", false));
                                                  buf.append(Integer.toString(comment_count));
                                                  buf.close();
                                              } catch (FileNotFoundException e) {
                                                  e.printStackTrace();
                                              } catch (IOException e) {
                                                  e.printStackTrace();
                                              }

                                          finish();
                                          }
                                      }
        );
        addcommentbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String getEdit = comment.getText().toString();
                if(getEdit.getBytes().length<=0){
                    Toast.makeText(EditActivity.this, "코멘트를 입력해주세요.", Toast.LENGTH_SHORT).show();
                }
                else {
                    CaptureUtil.captureView(gobanLayout, BlackPlayer, WhitePlayer);
                    Toast.makeText(EditActivity.this, "저장했습니다.", Toast.LENGTH_SHORT).show();

                    String str =comment.getText().toString();
// 파일 생성
                    File saveFile = new File(Environment.getExternalStorageDirectory().getAbsolutePath() + "/Baduk_Comment"+player_black+player_white); // 저장 경로
// 폴더 생성
                    if(!saveFile.exists()){ // 폴더 없을 경우
                        saveFile.mkdirs(); // 폴더 생성
                    }
                    try {
                        comment_count++;
                        long now = System.currentTimeMillis(); // 현재시간 받아오기
                        Date date = new Date(now); // Date 객체 생성
                        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
                        String nowTime = sdf.format(date);

                        BufferedWriter buf = new BufferedWriter(new FileWriter(saveFile+"/Comment.txt", true));
                        buf.append(Integer.toString(count));
                        buf.append("수\n");
                        buf.append("코멘트"+Integer.toString(comment_count) + ": "); // 날짜 쓰기
                        buf.append(str); // 파일 쓰기
                        buf.newLine(); // 개행
                        buf.close();
                    } catch (FileNotFoundException e) {
                        e.printStackTrace();
                    } catch (IOException e) {
                        e.printStackTrace();
                    }



                    try{
                        BufferedWriter bw = new BufferedWriter(new FileWriter(getFilesDir() + "test.txt", true));
                        bw.write("C["+comment.getText().toString()+"];");

                        bw.close();

                    }catch (Exception e){
                        e.printStackTrace();
                    }
                    comment.setText(null);
                }}
        });
        backbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                count--;
                gobutton[Lastrow][Lastcol].setBackgroundColor(Color.TRANSPARENT);
                gobutton[Lastrow][Lastcol].setEnabled(true);
                try{
                    BufferedReader br = new BufferedReader(new FileReader(getFilesDir()+"test.txt"));
                    String readStr = "";
                    String str = null;
                    while(((str = br.readLine()) != null)){
                        readStr += str +"\n";
                    }
                    br.close();

                    Toast.makeText(EditActivity.this, readStr.substring(0, readStr.length()-1), Toast.LENGTH_SHORT).show();

                }catch (FileNotFoundException e){
                    e.printStackTrace();
                }catch (IOException e) {
                    e.printStackTrace();
                }

                try{
                    BufferedWriter bw = new BufferedWriter(new FileWriter(getFilesDir() + "test.txt", false));
                    bw.write(getFilesDir()+"test.txt");
                    bw.close();

                }catch (Exception e){
                    e.printStackTrace();
                }
            }
        });
        int [][]btnId=
                {{R.id.imageButton_aa	,
                        R.id.imageButton_ab	,
                        R.id.imageButton_ac	,
                        R.id.imageButton_ad	,
                        R.id.imageButton_ae	,
                        R.id.imageButton_af	,
                        R.id.imageButton_ag	,
                        R.id.imageButton_ah	,
                        R.id.imageButton_ai	,
                        R.id.imageButton_aj	,
                        R.id.imageButton_ak	,
                        R.id.imageButton_al	,
                        R.id.imageButton_am	,
                        R.id.imageButton_an	,
                        R.id.imageButton_ao	,
                        R.id.imageButton_ap	,
                        R.id.imageButton_aq	,
                        R.id.imageButton_ar	,
                        R.id.imageButton_as
                },
                        {R.id.imageButton_ba ,
                                R.id.imageButton_bb    ,
                                R.id.imageButton_bc    ,
                                R.id.imageButton_bd    ,
                                R.id.imageButton_be    ,
                                R.id.imageButton_bf    ,
                                R.id.imageButton_bg    ,
                                R.id.imageButton_bh    ,
                                R.id.imageButton_bi    ,
                                R.id.imageButton_bj    ,
                                R.id.imageButton_bk    ,
                                R.id.imageButton_bl    ,
                                R.id.imageButton_bm    ,
                                R.id.imageButton_bn    ,
                                R.id.imageButton_bo    ,
                                R.id.imageButton_bp    ,
                                R.id.imageButton_bq    ,
                                R.id.imageButton_br    ,
                                R.id.imageButton_bs
                        },
                        {R.id.imageButton_ca ,
                                R.id.imageButton_cb    ,
                                R.id.imageButton_cc    ,
                                R.id.imageButton_cd    ,
                                R.id.imageButton_ce    ,
                                R.id.imageButton_cf    ,
                                R.id.imageButton_cg    ,
                                R.id.imageButton_ch    ,
                                R.id.imageButton_ci    ,
                                R.id.imageButton_cj    ,
                                R.id.imageButton_ck    ,
                                R.id.imageButton_cl    ,
                                R.id.imageButton_cm    ,
                                R.id.imageButton_cn    ,
                                R.id.imageButton_co    ,
                                R.id.imageButton_cp    ,
                                R.id.imageButton_cq    ,
                                R.id.imageButton_cr    ,
                                R.id.imageButton_cs
                        },{R.id.imageButton_ba ,
                        R.id.imageButton_db    ,
                        R.id.imageButton_dc    ,
                        R.id.imageButton_dd    ,
                        R.id.imageButton_de    ,
                        R.id.imageButton_df    ,
                        R.id.imageButton_dg    ,
                        R.id.imageButton_dh    ,
                        R.id.imageButton_di    ,
                        R.id.imageButton_dj    ,
                        R.id.imageButton_dk    ,
                        R.id.imageButton_dl    ,
                        R.id.imageButton_dm    ,
                        R.id.imageButton_dn    ,
                        R.id.imageButton_do    ,
                        R.id.imageButton_dp    ,
                        R.id.imageButton_dq    ,
                        R.id.imageButton_dr    ,
                        R.id.imageButton_ds}
                        ,{R.id.imageButton_ea ,
                        R.id.imageButton_eb    ,
                        R.id.imageButton_ec    ,
                        R.id.imageButton_ed    ,
                        R.id.imageButton_ee    ,
                        R.id.imageButton_ef    ,
                        R.id.imageButton_eg    ,
                        R.id.imageButton_eh    ,
                        R.id.imageButton_ei    ,
                        R.id.imageButton_ej    ,
                        R.id.imageButton_ek    ,
                        R.id.imageButton_el    ,
                        R.id.imageButton_em    ,
                        R.id.imageButton_en    ,
                        R.id.imageButton_eo    ,
                        R.id.imageButton_ep    ,
                        R.id.imageButton_eq    ,
                        R.id.imageButton_er    ,
                        R.id.imageButton_es},
                        {R.id.imageButton_fa ,
                                R.id.imageButton_fb    ,
                                R.id.imageButton_fc    ,
                                R.id.imageButton_fd    ,
                                R.id.imageButton_fe    ,
                                R.id.imageButton_ff    ,
                                R.id.imageButton_fg    ,
                                R.id.imageButton_fh    ,
                                R.id.imageButton_fi    ,
                                R.id.imageButton_fj    ,
                                R.id.imageButton_fk    ,
                                R.id.imageButton_fl    ,
                                R.id.imageButton_fm    ,
                                R.id.imageButton_fn    ,
                                R.id.imageButton_fo    ,
                                R.id.imageButton_fp    ,
                                R.id.imageButton_fq    ,
                                R.id.imageButton_fr    ,
                                R.id.imageButton_fs},
                        {R.id.imageButton_ga ,
                                R.id.imageButton_gb    ,
                                R.id.imageButton_gc    ,
                                R.id.imageButton_gd    ,
                                R.id.imageButton_ge    ,
                                R.id.imageButton_gf    ,
                                R.id.imageButton_gg    ,
                                R.id.imageButton_gh    ,
                                R.id.imageButton_gi    ,
                                R.id.imageButton_gj    ,
                                R.id.imageButton_gk    ,
                                R.id.imageButton_gl    ,
                                R.id.imageButton_gm    ,
                                R.id.imageButton_gn    ,
                                R.id.imageButton_go    ,
                                R.id.imageButton_gp    ,
                                R.id.imageButton_gq    ,
                                R.id.imageButton_gr    ,
                                R.id.imageButton_gs},

                        {R.id.imageButton_ha ,
                                R.id.imageButton_hb    ,
                                R.id.imageButton_hc    ,
                                R.id.imageButton_hd    ,
                                R.id.imageButton_he    ,
                                R.id.imageButton_hf    ,
                                R.id.imageButton_hg    ,
                                R.id.imageButton_hh    ,
                                R.id.imageButton_hi    ,
                                R.id.imageButton_hj    ,
                                R.id.imageButton_hk    ,
                                R.id.imageButton_hl    ,
                                R.id.imageButton_hm    ,
                                R.id.imageButton_hn    ,
                                R.id.imageButton_ho    ,
                                R.id.imageButton_hp    ,
                                R.id.imageButton_hq    ,
                                R.id.imageButton_hr    ,
                                R.id.imageButton_hs},
                        {R.id.imageButton_ia ,
                                R.id.imageButton_ib    ,
                                R.id.imageButton_ic    ,
                                R.id.imageButton_id    ,
                                R.id.imageButton_ie    ,
                                R.id.imageButton_if    ,
                                R.id.imageButton_ig    ,
                                R.id.imageButton_ih    ,
                                R.id.imageButton_ii    ,
                                R.id.imageButton_ij    ,
                                R.id.imageButton_ik    ,
                                R.id.imageButton_il    ,
                                R.id.imageButton_im    ,
                                R.id.imageButton_in    ,
                                R.id.imageButton_io    ,
                                R.id.imageButton_ip    ,
                                R.id.imageButton_iq    ,
                                R.id.imageButton_ir    ,
                                R.id.imageButton_is},
                        {R.id.imageButton_ja ,
                                R.id.imageButton_jb    ,
                                R.id.imageButton_jc    ,
                                R.id.imageButton_jd    ,
                                R.id.imageButton_je    ,
                                R.id.imageButton_jf    ,
                                R.id.imageButton_jg    ,
                                R.id.imageButton_jh    ,
                                R.id.imageButton_ji    ,
                                R.id.imageButton_jj    ,
                                R.id.imageButton_jk    ,
                                R.id.imageButton_jl    ,
                                R.id.imageButton_jm    ,
                                R.id.imageButton_jn    ,
                                R.id.imageButton_jo    ,
                                R.id.imageButton_jp    ,
                                R.id.imageButton_jq    ,
                                R.id.imageButton_jr    ,
                                R.id.imageButton_js},
                        {R.id.imageButton_ka ,
                                R.id.imageButton_kb    ,
                                R.id.imageButton_kc    ,
                                R.id.imageButton_kd    ,
                                R.id.imageButton_ke    ,
                                R.id.imageButton_kf    ,
                                R.id.imageButton_kg    ,
                                R.id.imageButton_kh    ,
                                R.id.imageButton_ki    ,
                                R.id.imageButton_kj    ,
                                R.id.imageButton_kk    ,
                                R.id.imageButton_kl    ,
                                R.id.imageButton_km    ,
                                R.id.imageButton_kn    ,
                                R.id.imageButton_ko    ,
                                R.id.imageButton_kp    ,
                                R.id.imageButton_kq    ,
                                R.id.imageButton_kr    ,
                                R.id.imageButton_ks},
                        {R.id.imageButton_la ,
                                R.id.imageButton_lb    ,
                                R.id.imageButton_lc    ,
                                R.id.imageButton_ld    ,
                                R.id.imageButton_le    ,
                                R.id.imageButton_lf    ,
                                R.id.imageButton_lg    ,
                                R.id.imageButton_lh    ,
                                R.id.imageButton_li    ,
                                R.id.imageButton_lj    ,
                                R.id.imageButton_lk    ,
                                R.id.imageButton_ll    ,
                                R.id.imageButton_lm    ,
                                R.id.imageButton_ln    ,
                                R.id.imageButton_lo    ,
                                R.id.imageButton_lp    ,
                                R.id.imageButton_lq    ,
                                R.id.imageButton_lr    ,
                                R.id.imageButton_ls},
                        {R.id.imageButton_ma ,
                                R.id.imageButton_mb    ,
                                R.id.imageButton_mc    ,
                                R.id.imageButton_md    ,
                                R.id.imageButton_me    ,
                                R.id.imageButton_mf    ,
                                R.id.imageButton_mg    ,
                                R.id.imageButton_mh    ,
                                R.id.imageButton_mi    ,
                                R.id.imageButton_mj    ,
                                R.id.imageButton_mk    ,
                                R.id.imageButton_ml    ,
                                R.id.imageButton_mm    ,
                                R.id.imageButton_mn    ,
                                R.id.imageButton_mo    ,
                                R.id.imageButton_mp    ,
                                R.id.imageButton_mq    ,
                                R.id.imageButton_mr    ,
                                R.id.imageButton_ms},
                        {R.id.imageButton_na ,
                                R.id.imageButton_nb    ,
                                R.id.imageButton_nc    ,
                                R.id.imageButton_nd    ,
                                R.id.imageButton_ne    ,
                                R.id.imageButton_nf    ,
                                R.id.imageButton_ng    ,
                                R.id.imageButton_nh    ,
                                R.id.imageButton_ni    ,
                                R.id.imageButton_nj    ,
                                R.id.imageButton_nk    ,
                                R.id.imageButton_nl    ,
                                R.id.imageButton_nm    ,
                                R.id.imageButton_nn    ,
                                R.id.imageButton_no    ,
                                R.id.imageButton_np    ,
                                R.id.imageButton_nq    ,
                                R.id.imageButton_nr    ,
                                R.id.imageButton_ns},
                        {R.id.imageButton_oa ,
                                R.id.imageButton_ob    ,
                                R.id.imageButton_oc    ,
                                R.id.imageButton_od    ,
                                R.id.imageButton_oe    ,
                                R.id.imageButton_of    ,
                                R.id.imageButton_og    ,
                                R.id.imageButton_oh    ,
                                R.id.imageButton_oi    ,
                                R.id.imageButton_oj    ,
                                R.id.imageButton_ok    ,
                                R.id.imageButton_ol    ,
                                R.id.imageButton_om    ,
                                R.id.imageButton_on    ,
                                R.id.imageButton_oo    ,
                                R.id.imageButton_op    ,
                                R.id.imageButton_oq    ,
                                R.id.imageButton_or    ,
                                R.id.imageButton_os},
                        {R.id.imageButton_pa ,
                                R.id.imageButton_pb    ,
                                R.id.imageButton_pc    ,
                                R.id.imageButton_pd    ,
                                R.id.imageButton_pe    ,
                                R.id.imageButton_pf    ,
                                R.id.imageButton_pg    ,
                                R.id.imageButton_ph    ,
                                R.id.imageButton_pi    ,
                                R.id.imageButton_pj    ,
                                R.id.imageButton_pk    ,
                                R.id.imageButton_pl    ,
                                R.id.imageButton_pm    ,
                                R.id.imageButton_pn    ,
                                R.id.imageButton_po    ,
                                R.id.imageButton_pp    ,
                                R.id.imageButton_pq    ,
                                R.id.imageButton_pr    ,
                                R.id.imageButton_ps},
                        {R.id.imageButton_qa ,
                                R.id.imageButton_qb    ,
                                R.id.imageButton_qc    ,
                                R.id.imageButton_qd    ,
                                R.id.imageButton_qe    ,
                                R.id.imageButton_qf    ,
                                R.id.imageButton_qg    ,
                                R.id.imageButton_qh    ,
                                R.id.imageButton_qi    ,
                                R.id.imageButton_qj    ,
                                R.id.imageButton_qk    ,
                                R.id.imageButton_ql    ,
                                R.id.imageButton_qm    ,
                                R.id.imageButton_qn    ,
                                R.id.imageButton_qo    ,
                                R.id.imageButton_qp    ,
                                R.id.imageButton_qq    ,
                                R.id.imageButton_qr    ,
                                R.id.imageButton_qs},
                        {R.id.imageButton_ra ,
                                R.id.imageButton_rb    ,
                                R.id.imageButton_rc    ,
                                R.id.imageButton_rd    ,
                                R.id.imageButton_re    ,
                                R.id.imageButton_rf    ,
                                R.id.imageButton_rg    ,
                                R.id.imageButton_rh    ,
                                R.id.imageButton_ri    ,
                                R.id.imageButton_rj    ,
                                R.id.imageButton_rk    ,
                                R.id.imageButton_rl    ,
                                R.id.imageButton_rm    ,
                                R.id.imageButton_rn    ,
                                R.id.imageButton_ro    ,
                                R.id.imageButton_rp    ,
                                R.id.imageButton_rq    ,
                                R.id.imageButton_rr    ,
                                R.id.imageButton_rs},
                        {R.id.imageButton_sa ,
                                R.id.imageButton_sb    ,
                                R.id.imageButton_sc    ,
                                R.id.imageButton_sd    ,
                                R.id.imageButton_se    ,
                                R.id.imageButton_sf    ,
                                R.id.imageButton_sg    ,
                                R.id.imageButton_sh    ,
                                R.id.imageButton_si    ,
                                R.id.imageButton_sj    ,
                                R.id.imageButton_sk    ,
                                R.id.imageButton_sl    ,
                                R.id.imageButton_sm    ,
                                R.id.imageButton_sn    ,
                                R.id.imageButton_so    ,
                                R.id.imageButton_sp    ,
                                R.id.imageButton_sq    ,
                                R.id.imageButton_sr    ,
                                R.id.imageButton_ss},

                };
        for(int j=0;j<=18;j++){
            for(int i=0;i<=18;i++){
                gobutton[j][i]=(ImageButton)findViewById(btnId[j][i]);
            }
        }

        for(int j=0;j<=18;j++) {
            for (int i = 0; i <=18; i++) {
                gobutton[j][i].setOnClickListener(new MyClickListener(j, i));

            }
        }
    }
}