package com.example.team2;

import android.graphics.Bitmap;
import android.os.Environment;
import android.view.View;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.text.SimpleDateFormat;

public class CaptureUtil {
    // 캡쳐가 저장될 외부 저장소
    private static final String CAPTURE_PATH = "/CAPTURE_GOBAN";
    static View view;
    public static void captureView(View Viewk, String p1, String p2) {
        view = Viewk;
        final String player_black="/"+p1;
        final String player_white="vs"+p2;
        Thread worker = new Thread() {
            public void run() {

                view.buildDrawingCache();
                Bitmap captureView = view.getDrawingCache();
                FileOutputStream fos;

                String strFolderPath = Environment.getExternalStorageDirectory() + CAPTURE_PATH+player_black+player_white;
                File folder = new File(strFolderPath);
                if(!folder.exists()) {
                    folder.mkdirs();
                }

                String strFilePath = strFolderPath + "/" + System.currentTimeMillis() + ".png";
                File fileCacheItem = new File(strFilePath);
                try {
                    fos = new FileOutputStream(fileCacheItem);
                    captureView.compress(Bitmap.CompressFormat.PNG, 100, fos);
                    view.destroyDrawingCache();
                } catch (FileNotFoundException e) {
                    e.printStackTrace();
                }
            }
        };
        worker.start();
    }

}
