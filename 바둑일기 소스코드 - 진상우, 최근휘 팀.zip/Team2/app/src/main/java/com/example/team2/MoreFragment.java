package com.example.team2;

import android.Manifest;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.database.Cursor;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.media.Image;
import android.net.Uri;
import android.nfc.Tag;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.design.widget.BottomNavigationView;
import android.support.v4.app.Fragment;
import android.support.v7.app.AppCompatActivity;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Toast;

import com.gun0912.tedpermission.PermissionListener;
import com.gun0912.tedpermission.TedPermission;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.Scanner;

public class MoreFragment extends Fragment {
    Bitmap image_bitmap;
    private static final String TAG = "두두두두";
    Uri imageURI;
    private File dir = new File("profile");
    private File profileImageURIFile = new File("profile_image.txt"); // 디렉터리 추가하면 exception throw
    private static final int PICK_FROM_ALBUM = 1;

    Button inputBtn;
    ImageView profileImage;
    View more;
    BitmapFactory.Options options;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        more = inflater.inflate(R.layout.fragment_more, container, false);

        options = new BitmapFactory.Options();

        //tedPermission();
        profileImage = more.findViewById(R.id.profileImage);
        inputBtn = more.findViewById(R.id.inputBtn);

        if (profileImageURIFile.exists()) {
            try {
                FileInputStream ifs = new FileInputStream(profileImageURIFile);
                byte txt[] = new byte[255];
                ifs.read(txt);
                ifs.close();
                imageURI = Uri.parse(new String(txt));
                image_bitmap = MediaStore.Images.Media.getBitmap(more.getContext().getContentResolver(), imageURI);
                profileImage.setImageBitmap(image_bitmap);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
        else {
            image_bitmap = BitmapFactory.decodeResource(getResources(), R.drawable.cam_default);
            profileImage.setImageBitmap(image_bitmap);
        }

        profileImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                goToAlbum();
            }
        });

        inputBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                saveURI();
            }
        });


        return more;
    }

    private void tedPermission() {
        PermissionListener permissionListener = new PermissionListener() {
            @Override
            public void onPermissionGranted() {
                // 권한 요청 성공

            }

            @Override
            public void onPermissionDenied(ArrayList<String> deniedPermissions) {
                // 권한 요청 실패
            }
        };

        TedPermission.with(more.getContext())
                .setPermissionListener(permissionListener)
                .setRationaleMessage(getResources().getString(R.string.permission_2))
                .setDeniedMessage(getResources().getString(R.string.permission_1))
                .setPermissions(Manifest.permission.WRITE_EXTERNAL_STORAGE, Manifest.permission.CAMERA)
                .check();
    }

    private void goToAlbum() {
        Intent intent = new Intent(Intent.ACTION_PICK);
        intent.setType(MediaStore.Images.Media.CONTENT_TYPE);
        startActivityForResult(intent, PICK_FROM_ALBUM);
    }

    @Override
    public void onActivityResult(int requestCode, int resultCode, Intent data) {
        if (resultCode != Activity.RESULT_OK) {

            Toast.makeText(more.getContext(), "취소 되었습니다.", Toast.LENGTH_SHORT).show();

            return;
        }

        if (requestCode == PICK_FROM_ALBUM) {
            Uri photoUri = data.getData();
            Cursor cursor = null;

            try {
                this.imageURI = data.getData();
                image_bitmap = MediaStore.Images.Media.getBitmap(more.getContext().getContentResolver(), imageURI);
                profileImage.setImageBitmap(image_bitmap);
            } catch (Exception e) {
                e.printStackTrace();
            } finally {
                if (cursor != null) {
                    cursor.close();
                }
            }
        }

    }

    void saveURI() {
        try {
            profileImageURIFile.mkdirs();
            FileOutputStream fos = more.getContext().openFileOutput(profileImageURIFile.toString(), Context.MODE_PRIVATE);
            fos.write(imageURI.toString().getBytes());
            Toast.makeText(more.getContext(), profileImageURIFile.toString() + "저장 되었습니다.", Toast.LENGTH_SHORT).show();
            fos.close();
        } catch (IOException e) {
            Toast.makeText(more.getContext(), "저장에 실패하였습니다.: " + profileImageURIFile.toString(), Toast.LENGTH_SHORT).show();
            e.printStackTrace();
        }
    }
}
