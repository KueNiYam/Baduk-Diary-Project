package com.example.team2;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.io.BufferedWriter;
import java.io.FileWriter;

public class EditorFragment extends Fragment {

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {

        final View edit = inflater.inflate(R.layout.activity_inform, container, false);

        Button b = (Button)edit.findViewById(R.id.button1);
        final EditText ET_PW, ET_PB,ET_DT,ET_KM,ET_RE;
        ET_PW=(EditText)edit.findViewById(R.id.ET_PW);
        ET_PB=(EditText)edit.findViewById(R.id.ET_PB);
        ET_DT=(EditText)edit.findViewById(R.id.ET_DT);
        ET_KM=(EditText)edit.findViewById(R.id.ET_KM);
        ET_RE=(EditText)edit.findViewById(R.id.ET_RE);



        b.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                try{
                    BufferedWriter bw = new BufferedWriter(new FileWriter(edit.getContext().getFilesDir() + "test.txt", false));
                    bw.write("(;PW["+ET_PW.getText().toString()+"]PB["+ET_PB.getText().toString()+"]DT["+ET_DT.getText().toString()+"]KM["+ET_KM.getText().toString()+"]RE["+ET_RE.getText().toString()+"]");
                    bw.close();

                }catch (Exception e){
                    e.printStackTrace();
                    Toast.makeText(edit.getContext(), e.getMessage(), Toast.LENGTH_SHORT).show();
                }
                Intent intent = new Intent(
                        getActivity(), // 현재 화면의 제어권자
                        EditActivity.class); // 다음 넘어갈 클래스 지정
                intent.putExtra("BlackName",ET_PB.getText().toString());
                intent.putExtra("WhiteName",ET_PW.getText().toString());
                startActivity(intent); // 다음 화면으로 넘어간다

            }
        });

        return edit;
    }
}
