package com.example.team2;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Bundle;
import android.os.Environment;
import android.support.v7.app.AppCompatActivity;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;

public class ViewActivity extends AppCompatActivity {
    Bitmap []map=null;

    String GameName;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view);
        Intent intent;
        intent = getIntent();
        GameName="/"+intent.getStringExtra("GameName") ;
        int commentNum =3;
        String line = null; // 한줄씩 읽기


        File loadFile = new File(Environment.getExternalStorageDirectory().getAbsolutePath() + "/Baduk_Comment"+GameName); // 저장 경로

        try {
            BufferedReader buf = new BufferedReader(new FileReader(loadFile+"/comment_count.txt"));

            line=buf.readLine();
            commentNum=Integer.parseInt(line);
            Toast.makeText(this, line, Toast.LENGTH_SHORT).show();

            buf.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        ImageView IV[]= new ImageView[commentNum];
        for (int i=0;i<commentNum;i++) {
            int size= 800;
            IV[i]=new ImageView(this);
            IV[i].setLayoutParams(new LinearLayout.LayoutParams(size,size));
            //이거 사진 크기 조정부분
        }
        if ( Environment.getExternalStorageState().equals(Environment.MEDIA_MOUNTED))
        {
            String path = Environment.getExternalStorageDirectory().getAbsolutePath()+"/CAPTURE_GOBAN"+GameName;
            File file = new File(path);
            String str;
            int num = 0;
            int imgCount = file.listFiles().length;
            // 파일 총 갯수 얻어오기
            map = new Bitmap[imgCount];
            Toast.makeText(ViewActivity.this, Integer.toString(imgCount), Toast.LENGTH_SHORT).show();
            if ( file.listFiles().length > 0 ){

                for ( File f : file.listFiles() ) {
                    str = f.getName();    // 파일 이름 얻어오기
                    map[num] = BitmapFactory.decodeFile(path + "/" + str);
                    IV[num].setImageBitmap(map[num]);
                    num++;
                }

            }
        }

        TextView TV[]= new TextView[commentNum];
        for (int i=0;i<commentNum;i++) {
            TV[i]=new TextView(this);
            TV[i].setLayoutParams(new LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT));
            //이거 텍스트 크기 조정부분
        }

        line = null;
        File loadFile1 = new File(Environment.getExternalStorageDirectory().getAbsolutePath() + "/Baduk_Comment"+GameName); // 저장 경로

        try {
            BufferedReader buf = new BufferedReader(new FileReader(loadFile1+"/Comment.txt"));

            for(int i=0;i<commentNum;i++){
                line=buf.readLine();
                TV[i].setText(line);
                TV[i].append("\n");
                line=buf.readLine();
                TV[i].append(line);
                TV[i].append("\n");
                // Integer.parseInt(line);
            }
            buf.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }


        LinearLayout rootLayout = (LinearLayout)findViewById(R.id.rootLayout);
        LinearLayout LL[] =new LinearLayout[commentNum];
        for (int i=0;i<commentNum;i++){

            LL[i] = new LinearLayout(this);
            LL[i].addView(IV[i]);
            LL[i].addView(TV[i]);
            rootLayout.addView(LL[i]);
        }

    }
}
