package com.example.team2;

import android.app.AlertDialog;
import android.content.Context;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.os.Environment;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.util.ArrayList;
import java.util.List;

public class ListFragment extends Fragment {
    ListAdapter listAdapter;

    private ListView listView;


    public void setDirEmpty(String dirName)
    {
        String path = Environment.getExternalStorageDirectory()  + dirName;
        File dir = new File(path);
        File[] childFileList = dir.listFiles();
        if (dir.exists())
        { for (File childFile : childFileList)
        { if (childFile.isDirectory())
        { setDirEmpty(childFile.getAbsolutePath()); }
        else
        { childFile.delete();
        } } dir.delete();
        }
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        String path = Environment.getExternalStorageDirectory().getAbsolutePath();
        File saveFile = new File(Environment.getExternalStorageDirectory() + "/Baduk_Comment"); // 저장 경로
        final File[] files = saveFile.listFiles();

        View list = inflater.inflate(R.layout.fragment_list, container, false);
        ListView lv =(ListView)list.findViewById(R.id.list_view);

        final List<String> dates = new ArrayList<>();
        for (int i=0; i< files.length; i++) {
            dates.add(files[i].getName());
        }

        final ArrayList<ItemData> items = new ArrayList<>();
        for (int i=0; i < files.length; ++i)
        {
            ItemData newItem = new ItemData();
            newItem.title = "기보 " + (i+1);
            newItem.date = dates.get(i);
            items.add(newItem);
        }

        listView = (ListView)list.findViewById(R.id.list_view);
        listAdapter = new ListAdapter(items);
        listView.setAdapter(listAdapter);
        // Listview on item click listener
        lv.setOnItemClickListener(new AdapterView.OnItemClickListener() {

                                      public void onItemClick(AdapterView<?> parent, View v,
                                                              int position, long id) {
                                          // getting values from selected ListItem
                                          Intent intent2 = new Intent(
                                                  getActivity(), // 현재 화면의 제어권자
                                                  ViewActivity.class); // 다음 넘어갈 클래스 지정
                                          intent2.putExtra("GameName", files[position].getName());
                                          startActivity(intent2); // 다음 화면으로 넘어간다
                                      }
                                  });
        lv.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override
            public boolean onItemLongClick(AdapterView<?> parent, View view, final int position, long id) {
                new AlertDialog.Builder(getContext())
                        .setTitle("정말로")
                        .setMessage("삭제하시겠습니까?")
                        .setIcon(android.R.drawable.ic_menu_delete)
                        .setPositiveButton(android.R.string.yes, new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int whichButton) {
                                // 확인시 처리 로직
                                setDirEmpty("/Baduk_Comment/"+files[position].getName());
                                setDirEmpty("/CAPTURE_GOBAN/"+files[position].getName());

                                items.remove(position);

                                Toast.makeText(getContext(), "삭제됨", Toast.LENGTH_SHORT).show();
                                listAdapter.notifyDataSetChanged();
                                listView.setAdapter(listAdapter);
                            }})
                        .setNegativeButton(android.R.string.no, new DialogInterface.OnClickListener() {
                            public void onClick(DialogInterface dialog, int whichButton) {
                                // 취소시 처리 로직
                                Toast.makeText(getContext(), "취소하였습니다.", Toast.LENGTH_SHORT).show();
                            }})
                        .show();
                return true;
            }
        });
        return list;
    }
}
class ListAdapter extends BaseAdapter {
    LayoutInflater inflater;
    private ArrayList<ItemData> items;

    public ListAdapter(ArrayList<ItemData> newItems) {
        items = newItems;
    }

    @Override
    public int getCount() {
        return items.size();
    }

    @Override
    public ItemData getItem(int position) {
        return items.get(position);
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        if (convertView == null)
        {
            final Context context = parent.getContext();
            if (inflater == null)
            {
                inflater = (LayoutInflater) context.getSystemService(Context.LAYOUT_INFLATER_SERVICE);
            }
            convertView = inflater.inflate(R.layout.list_item, parent, false);
        }

        TextView textTitle = (TextView) convertView.findViewById(R.id.textTitle);
        TextView textDate = (TextView) convertView.findViewById(R.id.textDate);

        textTitle.setText(this.getItem(position).title);
        textDate.setText(this.getItem(position).date);

        return convertView;
    }
}

class ItemData
{
    public String title;
    public String date;
}








